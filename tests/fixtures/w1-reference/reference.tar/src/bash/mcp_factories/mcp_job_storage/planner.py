"""Deterministic release preconditions. Never inspect, create or delete Docker objects."""
from __future__ import annotations

import datetime as dt

from mcp_preparation.contract import digest, json_bytes, sha256
from .contract import require, timestamp, validate


FRESH_SECONDS = 30


def release_plan(provider, provider_sha, state, state_sha, *, now):
    validate(provider)
    validate(state)
    sha256(provider_sha)
    sha256(state_sha)
    require(state["provider"] == provider["provider"] and state["provider_sha256"] == provider_sha,
            "job is not bound to this exact provider storage declaration")
    clock = timestamp(now)

    def fresh(value):
        return 0 <= (clock - timestamp(value)).total_seconds() <= FRESH_SECONDS

    common = []
    if not fresh(state["observed_at"]):
        common.append("stale-job-observation")
    if state["phase"] not in {"closed", "releasing", "released"}:
        common.append("admission-not-closed")
    if state["activity"] != "idle":
        common.append("job-busy-or-unknown")
    if not state["leases_complete"] or any(item["state"] != "released" for item in state["leases"]):
        common.append("active-or-unknown-lease")
    obligations = []
    if state["holds"]:
        obligations.append("retention-holds")
    inventory = state["protected_inventory"]
    if inventory["state"] != "verified" or inventory["unresolved_entries"]:
        obligations.append("unresolved-protected-content")
    for item in state["products"]:
        decision = item["decision"]
        if item["disposition"] == "pending":
            obligations.append("pending-product")
        elif state["phase"] != "released" and (decision["status"] != "verified" or not fresh(decision["verified_at"])):
            obligations.append("unverified-retention-or-discard")
    volumes = []
    for volume in sorted(state["volumes"], key=lambda item: item["role"]):
        blockers = list(common)
        if not fresh(volume["observed_at"]):
            blockers.append("stale-volume-observation")
        if volume["state"] == "unknown":
            blockers.append("volume-identity-unknown")
        if not volume["attachments_complete"] or volume["attachments"]:
            blockers.append("attached-or-unknown-container")
        if volume["role"] == "retained":
            blockers.extend(obligations)
        if volume["state"] == "absent" and volume["role"] == "retained" and obligations:
            blockers.append("missing-protected-volume")
        action = "blocked" if blockers else "already-absent" if volume["state"] == "absent" else "remove-volume"
        volumes.append({"id": volume["id"], "name": volume["name"], "role": volume["role"], "action": action,
                        "estimated_bytes": volume["bytes"], "blockers": sorted(set(blockers))})
    value = {"kind": "gacontext.job-storage-release-plan", "schema_version": 1,
             "registry_id": state["registry_id"], "job_id": state["job_id"], "binding_id": state["binding_id"],
             "provider": state["provider"], "provider_sha256": provider_sha, "state_sha256": state_sha,
             "daemon_id": state["daemon_id"], "expected_revision": state["revision"], "expected_epoch": state["epoch"],
             "planned_at": now, "expires_at": (clock + dt.timedelta(seconds=FRESH_SECONDS)).isoformat().replace("+00:00", "Z"),
             "read_only": True, "requires_live_revalidation": True, "execution_supported": False, "volumes": volumes,
             "retention_resolved": not obligations,
             "all_releasable": all(row["action"] != "blocked" for row in volumes)}
    return {"ok": True, "plan": value, "plan_sha256": digest(json_bytes(value))}
