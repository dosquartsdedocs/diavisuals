"""Bounded W1 envelopes and their cross-field semantics (Python 3.10+ stdlib)."""
from __future__ import annotations

import datetime as dt
import json
import pathlib
import re
import unicodedata

from mcp_preparation.contract import digest, fail, parse_json
from mcp_preparation.storage import read_regular


SCHEMA = pathlib.Path(__file__).resolve().parents[1] / "job-storage-v1.schema.json"
MAX_DOCUMENT = 1024 * 1024
KINDS = {"gacontext.job-storage-provider": "provider", "gacontext.job-storage-state": "state",
         "gacontext.job-product-retention": "retention", "gacontext.job-storage-request": "request",
         "gacontext.job-storage-binding": "binding"}
POLICIES = {"inputs": ("input-snapshots", "resolved-retention"), "results": ("results", "resolved-retention"),
            "exports": ("sealed-products", "resolved-retention"), "recovery": ("recovery", "resolved-retention"),
            "scratch": ("regenerable", "on-release")}


def require(condition, message, code="invalid-storage-contract"):
    if not condition:
        fail(code, message, invalid=True)


def timestamp(value):
    require(isinstance(value, str) and re.fullmatch(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,6})?Z", value),
            "storage timestamps must be UTC RFC3339 with Z")
    try:
        return dt.datetime.fromisoformat(value[:-1] + "+00:00")
    except ValueError:
        fail("invalid-storage-contract", "invalid storage observation time", invalid=True)


def relative_path(value):
    require(isinstance(value, str) and 0 < len(value) <= 1024 and unicodedata.normalize("NFC", value) == value,
            "storage paths must be bounded NFC relative paths")
    require(not any(unicodedata.category(char).startswith("C") or char in '\\:%$*?[]{}<>"|' for char in value),
            "storage path contains reserved characters")
    parts = value.split("/")
    require(len(parts) <= 64 and all(part not in {"", ".", ".."} and part == part.strip() and not part.endswith(".")
                                   and part.casefold() not in {".git", ".hg", ".svn"} and not part.startswith("~") for part in parts),
            "storage path escapes or aliases its declared root")
    return value


def shape(value, rule, definitions, where="document"):
    """Evaluate only the vocabulary in our checked-in schema, never remote schemas."""
    if "$ref" in rule:
        return shape(value, definitions[rule["$ref"].removeprefix("#/$defs/")], definitions, where)
    if "oneOf" in rule:
        from mcp_preparation.contract import PreparationError
        matches = 0
        for branch in rule["oneOf"]:
            try:
                shape(value, branch, definitions, where)
                matches += 1
            except PreparationError:
                pass
        require(matches == 1, f"{where}: expected one supported shape")
    types = {"object": dict, "array": list, "string": str, "integer": int, "boolean": bool, "null": type(None)}
    if "type" in rule:
        require(type(value) is types[rule["type"]], f"{where}: invalid type")
    for key in ("const", "enum"):
        if key in rule:
            choices = [rule[key]] if key == "const" else rule[key]
            require(any(type(value) is type(choice) and value == choice for choice in choices), f"{where}: unsupported value")
    if isinstance(value, dict):
        properties = rule.get("properties", {})
        require(set(rule.get("required", [])) <= value.keys(), f"{where}: missing fields")
        if rule.get("additionalProperties") is False:
            require(value.keys() <= properties.keys(), f"{where}: unknown fields")
        for key, item in value.items():
            if key in properties:
                shape(item, properties[key], definitions, where + "." + key)
    if isinstance(value, list):
        require(rule.get("minItems", 0) <= len(value) <= rule.get("maxItems", 4096), f"{where}: invalid array length")
        if rule.get("uniqueItems"):
            require(len({json.dumps(item, sort_keys=True) for item in value}) == len(value), f"{where}: duplicate entries")
        for item in value:
            shape(item, rule["items"], definitions, where + "[]")
    if isinstance(value, str):
        require(rule.get("minLength", 0) <= len(value) <= rule.get("maxLength", 8192), f"{where}: invalid string length")
        if "pattern" in rule:
            require(re.fullmatch(rule["pattern"], value) is not None, f"{where}: invalid string")
        if rule.get("format") == "date-time":
            timestamp(value)
    if type(value) is int:
        require(rule.get("minimum", value) <= value <= rule.get("maximum", value), f"{where}: integer outside bounds")


def labels(state, volume):
    values = {"contract": "docker-job-volumes-v1", "registry": state["registry_id"], "provider": state["provider"],
              "binding": state["binding_id"], "job": state["job_id"], "volume": volume["id"], "role": volume["role"]}
    return {"io.context.mcp-storage." + key: value for key, value in values.items()}


def validate(value):
    pending, nodes = [(value, 0)], 0
    while pending:
        item, depth = pending.pop()
        nodes += 1
        require(depth <= 32 and nodes <= 100000, "storage JSON exceeds depth/node bounds")
        if isinstance(item, dict):
            pending.extend((child, depth + 1) for child in item.values())
        elif isinstance(item, list):
            pending.extend((child, depth + 1) for child in item)
    schema = parse_json(read_regular(SCHEMA), maximum=MAX_DOCUMENT)
    require(isinstance(value, dict) and value.get("kind") in KINDS, "unsupported storage document kind")
    kind = KINDS[value["kind"]]
    shape(value, schema["$defs"][kind], schema["$defs"])
    if kind == "provider":
        policies = {item["path"]: (item["role"], item["cleanup"]) for item in value["path_policies"]}
        require(policies == POLICIES, "job policies must classify the five W1 roots exactly")
    elif kind == "state":
        for field in ("leases", "volumes", "products", "holds"):
            ids = [item["id"] for item in value[field]]
            require(len(ids) == len(set(ids)), f"duplicate {field} identity")
        require({item["role"] for item in value["volumes"]} == {"scratch", "retained"}, "one volume per W1 role is required")
        for volume in value["volumes"]:
            require(volume["name"] == "gacontext-job-" + volume["id"], "volume name must bind its unique incarnation")
            require(volume["labels"] == labels(value, volume), "volume labels disagree with the registered job/role")
            require(volume["daemon_id"] == value["daemon_id"], "volume daemon differs from the job daemon")
            require(timestamp(volume["created_at"]) <= timestamp(volume["observed_at"]), "volume observation predates creation")
            require(volume["state"] != "absent" or (volume["attachments_complete"] and not volume["attachments"]),
                    "an absent volume cannot have unknown or present attachments")
        for product in value["products"]:
            decision = product["decision"]
            if product["disposition"] == "pending":
                require(decision is None, "pending products cannot carry a completed decision")
            else:
                require(decision is not None and decision["bundle_sha256"] == product["bundle_sha256"], "decision must bind the exact sealed product")
                require(decision["kind"] == ("retention" if product["disposition"] == "acknowledged" else "user-discard"),
                        "decision kind differs from product disposition")
        protected = value["protected_inventory"]
        require(protected["state"] != "verified" or protected["tree_sha256"] is not None, "verified protected inventory requires its digest")
        if value["phase"] == "released":
            require(all(item["state"] == "absent" for item in value["volumes"]) and value["activity"] == "idle"
                    and value["leases_complete"] and all(item["state"] == "released" for item in value["leases"])
                    and not value["holds"] and protected["state"] == "verified" and not protected["unresolved_entries"]
                    and all(item["disposition"] != "pending" and item["decision"]["status"] == "verified" for item in value["products"]),
                    "released state still has resources or retention obligations")
    elif kind == "retention":
        relative_path(value["destination"]["path"])
        if value["destination"]["format"] == "directory":
            require(value["destination"]["content_sha256"] == value["bundle_sha256"], "directory retention binds exact bundle manifest bytes")
    elif kind == "binding":
        mounts = value["mounts"]
        expected = {"retained"} if value["access"] == "read-only" else {"scratch", "retained"}
        require(len(mounts) == len(expected) and {item["role"] for item in mounts} == expected,
                "readers mount retained only; writers require both distinct volume roles")
        require(len({item["id"] for item in mounts}) == len(mounts), "duplicate bound volume incarnation")
        require(all(item["name"] == "gacontext-job-" + item["id"] for item in mounts), "bound volume name differs from its incarnation")
    return value


def check_binding(binding, state):
    """Cross-check supplied observations; actual mount/lease authority stays with the manager."""
    validate(binding)
    validate(state)
    for key in ("registry_id", "job_id", "binding_id", "provider", "provider_sha256", "daemon_id", "epoch"):
        require(binding[key] == state[key], "job binding identity or fencing epoch differs", "storage-binding-mismatch")
    writable = binding["access"] == "read-write"
    require(state["leases_complete"] and state["phase"] in ({"open"} if writable else {"open", "draining", "closed"}),
            "job admission is fenced or lease inventory is incomplete", "storage-admission-closed")
    leases = [item for item in state["leases"] if item["id"] == binding["lease_id"]]
    require(len(leases) == 1 and leases[0]["state"] == "active"
            and leases[0]["kind"] in ({"writer"} if writable else {"reader", "transfer"}),
            "job mount requires its registered active access lease", "storage-lease-mismatch")
    for mount in binding["mounts"]:
        volume = next(item for item in state["volumes"] if item["role"] == mount["role"])
        require(volume["state"] == "verified" and all(mount[key] == volume[key] for key in ("id", "name", "marker_sha256")),
                "job mount differs from the registered volume incarnation", "storage-volume-mismatch")
    return {"ok": True, "read_only": True, "requires_live_revalidation": True}


def check_request(request, state):
    """Native storage hook preconditions; execution/authentication remain manager-owned."""
    validate(request)
    validate(state)
    require(request["kind"] == "gacontext.job-storage-request" and state["kind"] == "gacontext.job-storage-state",
            "expected a native storage request and job state")
    require(all(request[key] == state[key] for key in ("registry_id", "job_id")),
            "storage request addresses another job", "storage-binding-mismatch")
    if request["operation"] != "status":
        require(request["expected_revision"] == state["revision"] and request["expected_epoch"] == state["epoch"],
                "storage request revision or epoch is stale", "storage-revision-conflict")
        require(state["phase"] in ({"open"} if request["operation"] == "seal" else {"open", "draining", "closed"}),
                "storage operation requires eligible job admission", "storage-admission-closed")
        if request["operation"] == "seal":
            require(state["activity"] == "idle", "sealing needs quiescent domain work", "storage-busy")
    return {"ok": True, "read_only": True, "requires_live_revalidation": True}


def load(path, expected_sha=None):
    raw = read_regular(pathlib.Path(path), maximum=MAX_DOCUMENT)
    if expected_sha is not None:
        require(digest(raw) == expected_sha, "storage document differs from its expected SHA-256", "storage-digest-mismatch")
    return validate(parse_json(raw, maximum=MAX_DOCUMENT)), digest(raw)
